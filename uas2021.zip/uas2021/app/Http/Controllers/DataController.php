<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Auth;
use App\Models\User;

class DataController extends Controller
{
    public function data() {
        $data = "All data";
        return response()->json($data, 200);
    }

    public function dataAuth() {
        $iduser = Auth::user()->id;
        $userdata = User::find($iduser);
        $res = [];
        $res['nama'] = $userdata->name;
        $res['nim'] = $userdata->nim;
        $res['fakultas'] = $userdata->fakultas;
        $res['jurusan'] = $userdata->jurusan;
        $res['kelas'] = $userdata->kelas;
        return response()->json($res, 200);
    }
}